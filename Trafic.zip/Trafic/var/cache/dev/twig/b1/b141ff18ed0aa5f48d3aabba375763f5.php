<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* nav/index.html.twig */
class __TwigTemplate_8f3b6296fa5eb75ad0867f2d40b5f662 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "nav/index.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "nav/index.html.twig"));

        // line 1
        echo " 

    <nav class=\"navbar navbar-expand-lg navbar-light bg-light\">

        <a class=\"nav-link\" href=\"/\">Accueil</a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>

        <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
            <ul class=\"navbar-nav mr-auto\">
                   ";
        // line 12
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["module"]) || array_key_exists("module", $context) ? $context["module"] : (function () { throw new RuntimeError('Variable "module" does not exist.', 12, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["mod"]) {
            // line 13
            echo "    
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/module/";
            // line 15
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["mod"], "id", [], "any", false, false, false, 15), "html", null, true);
            echo "\">
            ";
            // line 16
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["mod"], "nom", [], "any", false, false, false, 16), "html", null, true);
            echo "
          </a>
        </li>

      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['mod'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "            </ul>
            <form class=\"form-inline my-2 my-lg-0\">

<script src=\"https://cdn.lordicon.com/fudrjiwc.js\"></script>
<lord-icon
    src=\"https://cdn.lordicon.com/gqdnbnwt.json\"
    trigger=\"loop\"
    delay=\"2000\"
    colors=\"primary:#121331,secondary:#08a88a\"
    style=\"width:40px;height:40px\">
</lord-icon>


            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" fill=\"none\" viewBox=\"0 0 24 24\">
<style>
  .user-1 {
\tanimation: user-1 1s cubic-bezier(0.83, -0.07, 0, 1.04) both infinite alternate-reverse;
}
@keyframes user-1 {
  0% {
    transform: translateY(0) translateX(0);
  }
  100% {
    transform: translateY(-1px) translateX(-2px);
  }
}
</style>
  <circle class=\"user-1\" cx=\"12\" cy=\"8.245\" r=\"2.5\" stroke=\"#FE7902\" stroke-width=\"1.5\"/>
  <ellipse cx=\"12\" cy=\"15.926\" stroke=\"#0A0A30\" stroke-width=\"1.5\" rx=\"5\" ry=\"2.329\"/>
</svg>

    </nav>";
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    public function getTemplateName()
    {
        return "nav/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  79 => 21,  68 => 16,  64 => 15,  60 => 13,  56 => 12,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source(" 

    <nav class=\"navbar navbar-expand-lg navbar-light bg-light\">

        <a class=\"nav-link\" href=\"/\">Accueil</a>
        <button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarSupportedContent\" aria-controls=\"navbarSupportedContent\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
            <span class=\"navbar-toggler-icon\"></span>
        </button>

        <div class=\"collapse navbar-collapse\" id=\"navbarSupportedContent\">
            <ul class=\"navbar-nav mr-auto\">
                   {% for mod in module %}
    
        <li class=\"nav-item\">
          <a class=\"nav-link\" href=\"/module/{{mod.id}}\">
            {{ mod.nom }}
          </a>
        </li>

      {% endfor %}
            </ul>
            <form class=\"form-inline my-2 my-lg-0\">

<script src=\"https://cdn.lordicon.com/fudrjiwc.js\"></script>
<lord-icon
    src=\"https://cdn.lordicon.com/gqdnbnwt.json\"
    trigger=\"loop\"
    delay=\"2000\"
    colors=\"primary:#121331,secondary:#08a88a\"
    style=\"width:40px;height:40px\">
</lord-icon>


            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"40\" height=\"40\" fill=\"none\" viewBox=\"0 0 24 24\">
<style>
  .user-1 {
\tanimation: user-1 1s cubic-bezier(0.83, -0.07, 0, 1.04) both infinite alternate-reverse;
}
@keyframes user-1 {
  0% {
    transform: translateY(0) translateX(0);
  }
  100% {
    transform: translateY(-1px) translateX(-2px);
  }
}
</style>
  <circle class=\"user-1\" cx=\"12\" cy=\"8.245\" r=\"2.5\" stroke=\"#FE7902\" stroke-width=\"1.5\"/>
  <ellipse cx=\"12\" cy=\"15.926\" stroke=\"#0A0A30\" stroke-width=\"1.5\" rx=\"5\" ry=\"2.329\"/>
</svg>

    </nav>", "nav/index.html.twig", "/home/billybob/Depot-SAV/Trafic/templates/nav/index.html.twig");
    }
}
