<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* crud/show.html.twig */
class __TwigTemplate_9c1dd5c4f2d0a9756317540576ead27a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javasripts' => [$this, 'block_javasripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "crud/show.html.twig"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "crud/show.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "crud/show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Module";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<div class=\"card\">
         ";
        // line 8
        echo "         <div class=\" px-3 pt-3 mb-3 text\">
         
                     <h3 class=\"text-center\">";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["module"]) || array_key_exists("module", $context) ? $context["module"] : (function () { throw new RuntimeError('Variable "module" does not exist.', 10, $this->source); })()), "nom", [], "any", false, false, false, 10), "html", null, true);
        echo "</h3>
     <div class=\"col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 \">                   
                            <img class=\"img1\" src='/image/";
        // line 12
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["module"]) || array_key_exists("module", $context) ? $context["module"] : (function () { throw new RuntimeError('Variable "module" does not exist.', 12, $this->source); })()), "photo", [], "any", false, false, false, 12), "html", null, true);
        echo "'/>
                            
                               <h5 class=\"text-center\"> Type d'équipement: ";
        // line 14
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["module"]) || array_key_exists("module", $context) ? $context["module"] : (function () { throw new RuntimeError('Variable "module" does not exist.', 14, $this->source); })()), "typemodule", [], "any", false, false, false, 14), "html", null, true);
        echo " </h5>
                               <h5 class=\"text-center\"> L'adresse IP: ";
        // line 15
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["module"]) || array_key_exists("module", $context) ? $context["module"] : (function () { throw new RuntimeError('Variable "module" does not exist.', 15, $this->source); })()), "adresseip", [], "any", false, false, false, 15), "html", null, true);
        echo " </h5> 
                              ";
        // line 17
        echo "                               ";
        if ((twig_get_attribute($this->env, $this->source, (isset($context["mesure"]) || array_key_exists("mesure", $context) ? $context["mesure"] : (function () { throw new RuntimeError('Variable "mesure" does not exist.', 17, $this->source); })()), "etat", [], "any", false, false, false, 17) == 1)) {
            // line 18
            echo "                               
                               <div class=\"alert alert-success\" role=\"alert\">
                                    L'équipement fontionne correctement
                                </div>
                               ";
        } else {
            // line 23
            echo "                               <div class=\"alert alert-danger\" role=\"alert\">
                                Attention une panne est détécter sur cet équipement 
                                </div>
                               ";
        }
        // line 26
        echo "                
                           
                                                    
                        </div>
                        ";
        // line 31
        echo "                        <div class=\"container\">
                            ";
        // line 33
        echo "                            <div class=\"controls\">
                                <h5 class=\"label\">Type de graphique</h5>
                            <select name=\"chartType\" id=\"chartType\" onchange=\"updateChartType()\">
                                <option value=\"line\">Line</option>
                                <option value=\"bar\">Bar</option>                             
                            </select>
                            
                        </div>
                    <div class=\"chart-container\" style=\"position: relative; width:85vw\">
                            <canvas id=\"myChart\" width=\"200\" height=\"100\"></canvas>
                         </div>    
                        </div>
                        ";
        // line 46
        echo "                        ";
        $this->displayBlock('javasripts', $context, $blocks);
        // line 86
        echo "                    </div>
              
        ";
        // line 89
        echo "  
    <a class=\"btn btn-info\" href=\"";
        // line 90
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_crud_index");
        echo "\">Retour en arrière</a>

    <a class=\"btn btn-success\" href=\"";
        // line 92
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_crud_edit", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["module"]) || array_key_exists("module", $context) ? $context["module"] : (function () { throw new RuntimeError('Variable "module" does not exist.', 92, $this->source); })()), "id", [], "any", false, false, false, 92)]), "html", null, true);
        echo "\">Modifier</a>
    
   
    </div>

</div>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    // line 46
    public function block_javasripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_5a27a8ba21ca79b61932376b2fa922d2 = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->enter($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javasripts"));

        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javasripts"));

        // line 47
        echo "
                         ";
        // line 48
        if ((twig_get_attribute($this->env, $this->source, (isset($context["mesure"]) || array_key_exists("mesure", $context) ? $context["mesure"] : (function () { throw new RuntimeError('Variable "mesure" does not exist.', 48, $this->source); })()), "etat", [], "any", false, false, false, 48) == 0)) {
            // line 49
            echo "                               
                               <script>
                                    alert(\"Une panne à été détectée\");
                                </script>
                               ";
        }
        // line 54
        echo "                        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js\" integrity=\"sha512-s+xg36jbIujB2S2VKfpGmlC3T5V2TF3lY48DX7u2r9XzGzgPsa6wTpOQA7J9iffvdeBN0q9tKzRxVxw1JviZPg==\" crossorigin=\"anonymous\"></script>
                        <script>

                                    myData = {
                                        labels: ";
        // line 58
        echo (isset($context["mesDate"]) || array_key_exists("mesDate", $context) ? $context["mesDate"] : (function () { throw new RuntimeError('Variable "mesDate" does not exist.', 58, $this->source); })());
        echo ",
                                        datasets: [
                                    {
                                        label: \"Donnée durant la journée\",
                                        fill: true,
                                        backgroundColor: 'rgba(19, 164, 236, 0.86)',
                                        borderColor: 'rgb(19, 206, 211))',
                                        data: ";
        // line 65
        echo (isset($context["mesValeur"]) || array_key_exists("mesValeur", $context) ? $context["mesValeur"] : (function () { throw new RuntimeError('Variable "mesValeur" does not exist.', 65, $this->source); })());
        echo ",
                                    }]
                                 };

                    Chart.defaults.global.defaultFontFamily = \"monospace\";
                    var ctx = document.getElementById('myChart').getContext('2d');
                    var myChart = new Chart(ctx, {
                    type: 'line',
                    data: myData
                });
                        ";
        // line 76
        echo "                        function updateChartType() {

                            myChart.destroy();
                                myChart = new Chart(ctx, {
                                type: document.getElementById(\"chartType\").value,
                                data: myData,
                            });
                        };
                    </script>
                        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        
        $__internal_5a27a8ba21ca79b61932376b2fa922d2->leave($__internal_5a27a8ba21ca79b61932376b2fa922d2_prof);

    }

    public function getTemplateName()
    {
        return "crud/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  236 => 76,  223 => 65,  213 => 58,  207 => 54,  200 => 49,  198 => 48,  195 => 47,  185 => 46,  168 => 92,  163 => 90,  160 => 89,  156 => 86,  153 => 46,  139 => 33,  136 => 31,  130 => 26,  124 => 23,  117 => 18,  114 => 17,  110 => 15,  106 => 14,  101 => 12,  96 => 10,  92 => 8,  89 => 6,  79 => 5,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Module{% endblock %}

{% block body %}
<div class=\"card\">
         {# Regroupe toutes les informations sur le module #}
         <div class=\" px-3 pt-3 mb-3 text\">
         
                     <h3 class=\"text-center\">{{ module.nom }}</h3>
     <div class=\"col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 \">                   
                            <img class=\"img1\" src='/image/{{ module.photo }}'/>
                            
                               <h5 class=\"text-center\"> Type d'équipement: {{ module.typemodule }} </h5>
                               <h5 class=\"text-center\"> L'adresse IP: {{ module.adresseip }} </h5> 
                              {# Boucle permettant de voir l'état du module  #}
                               {% if mesure.etat == 1 %}
                               
                               <div class=\"alert alert-success\" role=\"alert\">
                                    L'équipement fontionne correctement
                                </div>
                               {% else %}
                               <div class=\"alert alert-danger\" role=\"alert\">
                                Attention une panne est détécter sur cet équipement 
                                </div>
                               {% endif %}                
                           
                                                    
                        </div>
                        {# Graphique #}
                        <div class=\"container\">
                            {# Bouton permettant de changer de style de graphique #}
                            <div class=\"controls\">
                                <h5 class=\"label\">Type de graphique</h5>
                            <select name=\"chartType\" id=\"chartType\" onchange=\"updateChartType()\">
                                <option value=\"line\">Line</option>
                                <option value=\"bar\">Bar</option>                             
                            </select>
                            
                        </div>
                    <div class=\"chart-container\" style=\"position: relative; width:85vw\">
                            <canvas id=\"myChart\" width=\"200\" height=\"100\"></canvas>
                         </div>    
                        </div>
                        {# Le graphique en soit #}
                        {% block javasripts %}

                         {% if mesure.etat == 0 %}
                               
                               <script>
                                    alert(\"Une panne à été détectée\");
                                </script>
                               {% endif %}
                        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js\" integrity=\"sha512-s+xg36jbIujB2S2VKfpGmlC3T5V2TF3lY48DX7u2r9XzGzgPsa6wTpOQA7J9iffvdeBN0q9tKzRxVxw1JviZPg==\" crossorigin=\"anonymous\"></script>
                        <script>

                                    myData = {
                                        labels: {{ mesDate|raw }},
                                        datasets: [
                                    {
                                        label: \"Donnée durant la journée\",
                                        fill: true,
                                        backgroundColor: 'rgba(19, 164, 236, 0.86)',
                                        borderColor: 'rgb(19, 206, 211))',
                                        data: {{ mesValeur|raw }},
                                    }]
                                 };

                    Chart.defaults.global.defaultFontFamily = \"monospace\";
                    var ctx = document.getElementById('myChart').getContext('2d');
                    var myChart = new Chart(ctx, {
                    type: 'line',
                    data: myData
                });
                        {# Permet de changer de type de graphique #}
                        function updateChartType() {

                            myChart.destroy();
                                myChart = new Chart(ctx, {
                                type: document.getElementById(\"chartType\").value,
                                data: myData,
                            });
                        };
                    </script>
                        {% endblock %}
                    </div>
              
        {# <a href=\"{{ path('app_new') }}\">New </a> #}
  
    <a class=\"btn btn-info\" href=\"{{ path('app_crud_index') }}\">Retour en arrière</a>

    <a class=\"btn btn-success\" href=\"{{ path('app_crud_edit', {'id': module.id}) }}\">Modifier</a>
    
   
    </div>

</div>
{% endblock %}
", "crud/show.html.twig", "/home/billybob/Depot-SAV/Trafic/templates/crud/show.html.twig");
    }
}
